Helping Hands — Zero-Cost Starter Website

यह version इस बात को स्पष्ट करता है कि Helping Hands अभी एक शुरुआती सामाजिक पहल है।
मुख्य focus:
- Volunteers
- Shram Daan
- Time
- Skills
- छोटे और सत्यापित सेवा कार्य

Public donation section फिलहाल हटाया गया है ताकि formal registration और transparent financial व्यवस्था बनने से पहले website पर NGO/registered-charity जैसा impression न जाए।

Website खोलने के लिए index.html को Chrome में खोलें।

महत्वपूर्ण:
- केवल सत्यापित beneficiary stories/photos/impact numbers डालें।
- NGO registration होने से पहले registered NGO होने का दावा न करें।
- भविष्य में formal registration और financial setup होने पर donation section दोबारा जोड़ा जा सकता है।
